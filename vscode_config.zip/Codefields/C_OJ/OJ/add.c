#include <stdio.h>
int main ()
{
    int a=0,b=1;
    int sum = a+b;
    printf("The sum of %d and %d is %d",a,b,sum);
    return 0;
}